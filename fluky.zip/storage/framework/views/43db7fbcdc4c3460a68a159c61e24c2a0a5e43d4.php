<?php $__env->startSection('title', __('Meta title')); ?>
<?php $__env->startSection('description', __('Meta description')); ?>
<?php $__env->startSection('keywords', __('Meta keywords')); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dashboard">

        <div id="permission"></div>
        <canvas id="canvas" class="hide"></canvas>

        <!-- video section :: start -->
        <div class="container-fluid main video-dask">
            <div class="row">
                <?php if(getFeature('VIDEO_CHAT', 'status') == 'active'): ?>
                    <div class="col-12 col-md-5 col-lg-5 col-xl-3 video-section pr-0">
                        <div class="remote-video-container">
                            <div class="remote-user-info hide">
                                <img id="partnerCountryVideo" src="" alt="<?php echo e(__('Country Flag')); ?>" width="25" />
                                <span id="partnerName"></span>
                            </div>
                            <button class="action-video report hide" data-toggle="tooltip" data-placement="top"
                                title="<?php echo e(__('Report')); ?>"><i class="fa fa-flag"></i></button>
                            <video id="remoteVideo" autoplay playsinline></video>
                            <i class="fa fa-video video-load-icon"></i>
                        </div>
                        <div class="local-video-container">
                            <video id="localVideo" muted autoplay playsinline></video>
                            <i class="fa fa-video video-load-icon"></i>
                            <div class="video-actions">
                                <button class="action-video video-off" data-toggle="tooltip" data-placement="top"
                                    title="<?php echo e(__('Camera Off')); ?>"><i class="fa fa-video"></i></button>
                                <button class="action-video hide video-on" data-toggle="tooltip" data-placement="top"
                                    title="<?php echo e(__('Camera On')); ?>"><i class="fa fa-video-slash"></i></button>
                                <button class="action-video audio-mute" data-toggle="tooltip" data-placement="top"
                                    title="<?php echo e(__('Mute Audio')); ?>"><i class="fa fa-microphone"></i></button>
                                <button class="action-video hide audio-unmute" data-toggle="tooltip" data-placement="top"
                                    title="<?php echo e(__('Unmute Audio')); ?>"><i class="fa fa-microphone-slash"></i></button>
                                <button class="action-video rotate" data-toggle="tooltip" data-placement="top"
                                    title="<?php echo e(__('Rotate Camera')); ?>"><i class="fa fa-camera"></i></button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div
                    class="col-12 <?php echo e(getFeature('VIDEO_CHAT', 'status') == 'active' ? 'col-md-7 col-lg-7 col-xl-9' : 'col-md-12 col-lg-12 text-chat-panel'); ?> chat-main">
                    <div class="row d-flex align-items-center">
                        <!-- call button options :: start -->
                        <div class="col-12 text-center chat-section">
                            <div class="btn-actions">
                                <div class="row align-items-center">
                                    <div class="col-4 col-md-4 col-lg-5 pr-0 text-left">
                                        <span class="mb-0 mt-0">
                                            <img id="partnerCountryText" class="d-none mr-1" src="images/globe.png"
                                                alt="<?php echo e(__('Country Flag')); ?>" width="25" />
                                        </span>
                                        <?php if(getFeature('TEXT_CHAT', 'status') == 'active'): ?>
                                            <button id="text" class="btn btn-theme" title="<?php echo e(__('Text chat')); ?>">
                                                <i class="fa fa-comments"></i>
                                                <span class="d-none d-lg-inline-block"><?php echo e(__('Text')); ?></span>
                                            </button>
                                        <?php endif; ?>
                                        <?php if(getFeature('VIDEO_CHAT', 'status') == 'active'): ?>
                                            <button id="video" class="btn btn-theme" title="<?php echo e(__('Video chat')); ?>">
                                                <i class="fa fa-video"></i>
                                                <span class="d-none d-lg-inline-block"><?php echo e(__('Video')); ?></span>
                                            </button>
                                        <?php endif; ?>
                                        <button id="stop" class="btn btn-theme hide">
                                            <i class="fa fa-stop"></i>
                                            <span class="d-none d-lg-inline-block"><?php echo e(__('Stop')); ?></span>
                                        </button>
                                        <button id="next" class="btn btn-theme hide search-next">
                                            <i class="fa fa-random"></i>
                                            <span class="d-none d-lg-inline-block"><?php echo e(__('Next')); ?></span>
                                        </button>
                                    </div>
                                    <div class="col-8 col-md-8 col-lg-7 pl-0 text-right filter-options">
                                        <?php if(getFeature('GENDER_FILTER', 'status') == 'active'): ?>
                                            <label class="mb-0"><i class="fa fa-users"></i></label>
                                            <select id="genderFilter">
                                                <option value=""><?php echo e(__('Gender: All')); ?></option>
                                                <option value="male"><?php echo e(__('Male')); ?></option>
                                                <option value="female"><?php echo e(__('Female')); ?></option>
                                            </select>
                                        <?php else: ?>
                                            <select id="genderFilter" hidden></select>
                                        <?php endif; ?>
                                        <?php if(getFeature('COUNTRY_FILTER', 'status') == 'active'): ?>
                                            <label class="ml-2 mb-0"><i class="fa fa-flag"></i></label>
                                            <select id="countryFilter">
                                                <option value=""><?php echo e(__('Country: All')); ?></option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->code); ?>">
                                                        <?php echo e($country->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php else: ?>
                                            <select id="countryFilter" hidden></select>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- call button options :: end -->

                        <!-- chat area :: start -->
                        <div class="col-12 chat-area">
                            <!-- about us  :: start -->
                            <div class="about">
                                <div class="text-justify description">
                                    <?php echo getContent('HOME_PAGE'); ?>

                                </div>
                            </div>
                            <!-- about us  :: end -->
                            <!-- chat panel :: starts -->
                            <div class="chat-panel hide">
                                <div class="chat-box">
                                    <div class="chat-body"></div>
                                    <div class="chat-footer">
                                        <form id="chatForm">
                                            <div class="input-group">
                                                <input type="text" id="messageInput" class="form-control note-input"
                                                    placeholder="<?php echo e(__('Type a message')); ?>" autocomplete="off"
                                                    maxlength="100" disabled />
                                                <div class="input-group-append">
                                                    <button id="send" class="btn btn-outline-secondary" type="submit"
                                                        title="<?php echo e(__('Send')); ?>" disabled>
                                                        <i class="far fa-paper-plane"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- chat panel :: end -->
                        </div>
                        <!-- chat area :: end -->
                    </div>
                </div>
            </div>
        </div>
        <!-- video section :: end -->

    </section>

    <!-- notice modal starts -->
    <div class="modal fade" id="noticeModal" tabindex="-1" role="dialog" aria-labelledby="noticeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="noticeModalLabel"><?php echo e(__('Welcome')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="welcomeForm">
                    <div class="modal-body terms_modal">
                        <?php if(getFeature('GENDER_FILTER', 'status') == 'active'): ?>
                            <div class="form-group">
                                <label>
                                    <?php echo e(__("I'm")); ?>

                                </label>
                                <select id="gender" class="form-control" required>
                                    <option value=""><?php echo e(__('Select')); ?></option>
                                    <option value="male"><?php echo e(__('Male')); ?></option>
                                    <option value="female"><?php echo e(__('Female')); ?></option>
                                </select>
                            </div>
                        <?php else: ?>
                            <select id="gender" hidden></select>
                        <?php endif; ?>
                        <label>
                            <?php echo e(__('By clicking Continue & Start you certify that you are over :age years old and accept our Terms & Conditions and our Privacy Policy', ['age' => getSetting('MINIMUM_AGE')])); ?>

                        </label>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="start" class="btn btn-theme"><?php echo e(__('Confirm & Start')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- notice modal ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/socket.io.js')); ?>"></script>
    <script src="<?php echo e(asset('js/adapter.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.1.1\resources\views/home.blade.php ENDPATH**/ ?>