<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dashboard">
        <div class="loader loader--style1">
            <svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                x="0px" y="0px" width="80px" height="80px" viewBox="0 0 40 40" enable-background="new 0 0 40 40"
                xml:space="preserve">
                <path opacity="0.2" fill="#ec250d"
                    d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
                                                                    s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
                                                                    c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z" />
                <path fill="#ec250d" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
                                                                    C22.32,8.481,24.301,9.057,26.013,10.047z">
                    <animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 20 20"
                        to="360 20 20" dur="0.5s" repeatCount="indefinite" />
                </path>
            </svg>
        </div>

        <div id="permission"></div>
        <canvas id="canvas" class="hide"></canvas>

        <!-- video section :: start -->
        <div class="container-fluid mt-1 main">
            <div class="row">
                <?php if(getFeature('VIDEO_CHAT', 'status') == 'active'): ?>
                    <div class="col-12 col-md-4 col-lg-3 video-section pr-0">
                        <div class="remote-video-container">
                            <div class="remote-user-info hide">
                                <img id="partnerCountryVideo" src="" alt="Country Flag" width="25" />
                                <span id="partnerName"></span>
                            </div>
                            <button class="action-video report hide" data-toggle="tooltip" data-placement="top" title="Report"><i
                                    class="fa fa-flag"></i></button>
                            <video id="remoteVideo" autoplay playsinline></video>
                            <!-- <img src="images/preloader.png" /> -->
                            <i class="fa fa-video video-load-icon"></i>
                            
                        </div>
                        <div class="local-video-container">
                            <video id="localVideo" muted autoplay playsinline></video>
                            <!-- <img src="images/preloader.png" /> -->
                            <i class="fa fa-video  video-load-icon"></i>
                            <div class="video-actions">
                                <button class="action-video video-off" data-toggle="tooltip" data-placement="top"
                                    title="Camera Off"><i class="fa fa-video"></i></button>
                                <button class="action-video hide video-on" data-toggle="tooltip" data-placement="top"
                                    title="Camera On"><i class="fa fa-video-slash"></i></button>
                                <button class="action-video audio-mute" data-toggle="tooltip" data-placement="top"
                                    title="Mute Audio"><i class="fa fa-microphone"></i></button>
                                <button class="action-video hide audio-unmute" data-toggle="tooltip" data-placement="top"
                                    title="Unmute Audio"><i class="fa fa-microphone-slash"></i></button>
                                <button class="action-video rotate" data-toggle="tooltip" data-placement="top"
                                    title="Rotate Camera"><i class="fa fa-camera"></i></button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-12 <?php echo e(getFeature('VIDEO_CHAT', 'status') == 'active' ? 'col-md-8 col-lg-9' : 'col-md-12 col-lg-12 text-chat-panel'); ?> chat-main">
                    <div class="row d-flex align-items-center">
                        <!-- call button options :: start -->
                        <div class="col-12 text-center chat-section">
                            <div class="btn-actions">
                                <div class="row">
                                    <div class="col-12 col-lg-5 pr-0 text-left">
                                        <h5 class="mb-0 mt-0">
                                            <img id="partnerCountryText" class="d-none" src="images/globe.png" alt="Country Flag"
                                                width="25" />
                                        </h5>
                                        <?php if(getFeature('TEXT_CHAT', 'status') == 'active'): ?>
                                            <button id="text" class="btn btn-theme" title="Text chat">
                                                <i class="fa fa-comments"></i>
                                                <span class="d-none d-sm-inline-block">Text</span>
                                            </button>
                                        <?php endif; ?>
                                        <?php if(getFeature('VIDEO_CHAT', 'status') == 'active'): ?>
                                            <button id="video" class="btn btn-theme" title="Video chat">
                                                <i class="fa fa-video"></i>
                                                <span class="d-none d-sm-inline-block">Video</span>
                                            </button>
                                        <?php endif; ?>
                                        <button id="stop" class="btn btn-theme hide">
                                            <i class="fa fa-stop"></i>
                                            <span class="d-none d-sm-inline-block">Stop</span>
                                        </button>
                                        <button id="next" class="btn btn-theme hide search-next">
                                            <i class="fa fa-random"></i>
                                            <span class="d-none d-sm-inline-block">Next</span>
                                        </button>
                                    </div>
                                    <div class="col-12 col-lg-7 pl-0 text-right">
                                        <?php if(getFeature('GENDER_FILTER', 'status') == 'active'): ?>
                                            <label class="mb-0">Show</label>
                                            <select id="genderFilter" class="">
                                                <option value="">All</option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        <?php endif; ?>
                                        <?php if(getFeature('COUNTRY_FILTER', 'status') == 'active'): ?>
                                            <label class="ml-2 mb-0">Country</label>
                                            <select id="countryFilter" class="">
                                                <option value="">All</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->code); ?>">
                                                        <?php echo e($country->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- call button options :: end -->

                        <!-- chat area :: start -->
                        <div class="col-12 chat-area">
                            <!-- about us  :: start -->
                            <div class="about">
                                <div class="text-justify description">
                                    <?php echo getContent('HOME_PAGE'); ?>

                                </div>
                            </div>
                            <!-- about us  :: end -->
                            <!-- chat panel :: starts -->
                            <div class="chat-panel hide">
                                <div class="chat-box">
                                    <div class="chat-body"></div>
                                    <div class="chat-footer">
                                        <form id="chatForm">
                                            <div class="input-group">
                                                <input type="text" id="messageInput" class="form-control note-input"
                                                    placeholder="Type a message..." autocomplete="off" maxlength="100"
                                                    disabled />
                                                <div class="input-group-append">
                                                    <button id="send" class="btn btn-outline-secondary" type="submit"
                                                        title="Send" disabled>
                                                        <i class="far fa-paper-plane"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- chat panel :: end -->
                        </div>
                        <!-- chat area :: end -->
                    </div>
                </div>
            </div>
        </div>
        <!-- video section :: end -->

    </section>

    <!-- notice modal starts -->
    <div class="modal fade" id="noticeModal" tabindex="-1" role="dialog" aria-labelledby="noticeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="noticeModalLabel">Welcome</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="welcomeForm">
                    <div class="modal-body terms_modal">
                        <div class="form-group">
                            <label>
                                I'm
                            </label>
                            <select id="gender" class="form-control" required>
                                <option value="">--Select--</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <label>
                            By clicking <b>Continue & Start</b> you certify that you are over
                            <?php echo e(getSetting('MINIMUM_AGE')); ?> years old and accept our <a href="<?php echo e(route('termsAndConditions')); ?>"
                                target="_blank">Terms & Conditions</a> and our
                            <a href="<?php echo e(route('privacyPolicy')); ?>" target="_blank">Privacy Policy</a>.
                        </label>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="start" class="btn btn-theme">Confirm & Start</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- notice modal ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        const username = "<?php echo e(Auth::check() ? Auth::user()->username : getSetting('DEFAULT_USERNAME')); ?>";
        const userGender = "<?php echo e(Auth::user() ? Auth::user()->gender : ''); ?>";
        const stunUrl = "<?php echo e(getSetting('STUN_URL')); ?>";
        const turnUrl = "<?php echo e(getSetting('TURN_URL')); ?>";
        const turnUsername = "<?php echo e(getSetting('TURN_USERNAME')); ?>";
        const turnPassword = "<?php echo e(getSetting('TURN_PASSWORD')); ?>";
        const defaultUsername = "<?php echo e(getSetting('DEFAULT_USERNAME')); ?>";
        const appName = "<?php echo e(getSetting('APPLICATION_NAME')); ?>";
        const signalingURL = "<?php echo e(getSetting('SIGNALING_URL')); ?>";
        const authMode = "<?php echo e(getSetting('AUTH_MODE')); ?>";
        const ip = "<?php echo e($ip); ?>";
        const textChatPaid = "<?php echo e(getFeature('TEXT_CHAT', 'paid')); ?>" == 'yes';
        const videoChatPaid = "<?php echo e(getFeature('VIDEO_CHAT', 'paid')); ?>" == 'yes';
        const genderFilterPaid = "<?php echo e(getFeature('GENDER_FILTER', 'paid')); ?>" == 'yes';
        const countryFilterPaid = "<?php echo e(getFeature('COUNTRY_FILTER', 'paid')); ?>" == 'yes';
        const userType = "<?php echo e(auth()->user() ? auth()->user()->plan_type : 'free'); ?>";
        const paidPlanName = "<?php echo e(getSetting('PRICING_PLAN_NAME_PAID')); ?>";
        const primaryColor = "<?php echo e(getSetting('THEME_COLOR')); ?>";
        const userLoggedIn = "<?php echo e(auth()->check()); ?>";
    </script>
    <script src="<?php echo e(asset('js/socket.io.js')); ?>"></script>
    <script src="<?php echo e(asset('js/trip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/adapter.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky_2.0.0_9_8\resources\views/home.blade.php ENDPATH**/ ?>