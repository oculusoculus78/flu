<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid text-center">
		<h3><?php echo e($page); ?></h3>
		<div class="col-12 col-md-10 mt-3 offset-md-1 text-justify">
    		<?php echo getContent('PRIVACY_POLICY'); ?>

    	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0_9_8_13_08\resources\views/privacy-policy.blade.php ENDPATH**/ ?>